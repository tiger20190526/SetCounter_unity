﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public class DrawGUIOrderColorPicker : MonoBehaviour {

	public bool loadFromScene = true;
	public GameObject pickerPrefab;
	public ColorPicker[] colorPicker;

	private List<ColorPicker> mColorPickerList;

	void Start()
	{
//		if(loadFromScene)
//		{
//			colorPicker = GameObject.FindObjectsOfType<ColorPicker>();
//		}
//		mColorPickerList = new List<ColorPicker>();
//		mColorPickerList.AddRange(colorPicker);
//
//		mColorPickerList = mColorPickerList.OrderBy(item => item.drawOrder).ToList();
//		mColorPickerList.Reverse();
//		mColorPickerList.CopyTo(colorPicker);
//
//		foreach(var elem in mColorPickerList)
//		{
//			elem.useExternalDrawer = true;
//		}
	}

	public void InitPicker(int pickerCount)
	{
		mColorPickerList = new List<ColorPicker> ();
		colorPicker = new ColorPicker[pickerCount];
		for (int i = 0; i < pickerCount; i++) {
			ColorPicker picker = Instantiate (pickerPrefab, this.transform).GetComponent<ColorPicker>();
			picker.Title = "Color" + (i + 1).ToString();
			picker.startPos = new Vector2 (20, 30 * (i + 1));
			// picker.receiver = PieceGenerator.Instance.gameObject;
			picker.colorSetFunctionName = "SetNumberColor";
			picker.colorGetFunctionName = "GetNumberColor";
			picker.index = i;
			picker.drawOrder = i + 1;
			mColorPickerList.Add (picker);
		}

		mColorPickerList = mColorPickerList.OrderBy(item => item.drawOrder).ToList();
		mColorPickerList.Reverse();
		mColorPickerList.CopyTo(colorPicker);

		foreach(var elem in mColorPickerList)
		{
			elem.useExternalDrawer = true;
		}
	}

	void OnGUI () 
	{
		foreach(var elem in mColorPickerList)
		{
			elem._DrawGUI();
		}
	}
}
